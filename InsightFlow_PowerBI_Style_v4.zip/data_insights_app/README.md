# InsightFlow — Interactive Analytics Studio

Power BI-style Streamlit dashboard: upload CSV/Excel, automatically clean data, apply global filters, explore interactive Plotly charts, inspect data quality, generate automated business insights, and export filtered data.

## Run on Windows
```bash
pip install -r requirements.txt
streamlit run app.py
```
Open http://localhost:8501
