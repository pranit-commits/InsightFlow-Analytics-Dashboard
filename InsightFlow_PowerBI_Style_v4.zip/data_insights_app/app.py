import io
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(
    page_title="InsightFlow | Interactive Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -----------------------------
# Power BI-style visual system
# -----------------------------
st.markdown("""
<style>
/* App canvas */
[data-testid="stAppViewContainer"] { background: #f5f7fb; }
[data-testid="stHeader"] { background: transparent; }
.block-container { padding: 1.0rem 1.5rem 2.5rem; max-width: 1800px; }

/* Sidebar */
section[data-testid="stSidebar"] {
    width: 300px !important;
    background: #ffffff;
    border-right: 1px solid #e7eaf0;
}
section[data-testid="stSidebar"] > div { padding-top: 1rem; }

/* Hide Streamlit chrome for a cleaner BI feel */
#MainMenu { visibility: hidden; }
footer { visibility: hidden; }
[data-testid="stToolbar"] { visibility: hidden; }

/* Top navigation / brand */
.pbi-topbar {
    display:flex; align-items:center; justify-content:space-between;
    background:#ffffff; border:1px solid #e7eaf0; border-radius:16px;
    padding:14px 18px; margin-bottom:14px;
    box-shadow:0 2px 10px rgba(20,30,55,.04);
}
.brand-wrap { display:flex; align-items:center; gap:12px; min-width:0; }
.brand-icon {
    width:42px; height:42px; border-radius:11px; display:flex; align-items:center;
    justify-content:center; font-size:22px; background:#eef2ff;
}
.brand-title {
    font-size:clamp(1.15rem, 2.1vw, 1.65rem); font-weight:800; line-height:1.15;
    color:#172033; margin:0; overflow-wrap:anywhere;
}
.brand-sub { color:#6b7280; font-size:.82rem; margin-top:4px; }
.live-pill {
    border:1px solid #dfe5ee; border-radius:999px; padding:7px 11px;
    font-size:.76rem; color:#4b5563; background:#fafbfc; white-space:nowrap;
}

/* KPI cards */
[data-testid="stMetric"] {
    background:#ffffff !important; border:1px solid #e7eaf0 !important;
    border-radius:14px !important; padding:15px 17px !important;
    box-shadow:0 2px 10px rgba(20,30,55,.035);
}
[data-testid="stMetricLabel"] { color:#697386 !important; font-weight:600 !important; }
[data-testid="stMetricValue"] { color:#172033 !important; font-weight:800 !important; }

/* Tabs */
button[data-baseweb="tab"] {
    border-radius:9px 9px 0 0; font-weight:650; padding:9px 15px;
}
button[data-baseweb="tab"] p { font-size:.86rem; }

/* Cards around chart blocks */
.section-card {
    background:#ffffff; border:1px solid #e7eaf0; border-radius:15px;
    padding:8px 10px 4px; box-shadow:0 2px 10px rgba(20,30,55,.035);
}
.section-title { font-weight:750; color:#172033; font-size:1rem; margin:2px 4px 8px; }

/* Filter info strip */
.filter-strip {
    background:#eef4ff; border:1px solid #d9e5ff; border-radius:11px;
    padding:9px 13px; color:#334155; margin:5px 0 13px;
}

/* Sidebar headings */
.side-brand { font-size:1.2rem; font-weight:800; color:#172033; margin-bottom:2px; }
.side-caption { color:#7b8494; font-size:.78rem; margin-bottom:14px; }

/* Buttons */
.stDownloadButton button, .stButton button { border-radius:9px; font-weight:650; }

/* Dataframe */
[data-testid="stDataFrame"] { border-radius:12px; overflow:hidden; }

/* Responsive */
@media (max-width: 900px) {
    .block-container { padding-left: .8rem; padding-right: .8rem; }
    .pbi-topbar { padding:12px; }
    .live-pill { display:none; }
}
</style>
""", unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def load_data(uploaded_file):
    if uploaded_file.name.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(uploaded_file)
    return pd.read_csv(uploaded_file)


def clean_data(df):
    df = df.copy()
    log = []
    original_shape = df.shape
    df.dropna(axis=0, how="all", inplace=True)
    df.dropna(axis=1, how="all", inplace=True)
    df.columns = [str(c).strip() for c in df.columns]
    dup = int(df.duplicated().sum())
    if dup:
        df.drop_duplicates(inplace=True)
        log.append(f"Removed {dup} duplicate rows.")
    for c in df.columns:
        if df[c].dtype == "object":
            n = pd.to_numeric(df[c], errors="coerce")
            if n.notna().mean() > .8:
                df[c] = n
                log.append(f"Converted {c} to numeric.")
            else:
                d = pd.to_datetime(df[c], errors="coerce")
                if d.notna().mean() > .8:
                    df[c] = d
                    log.append(f"Converted {c} to date.")
    for c in df.columns:
        m = int(df[c].isna().sum())
        if not m:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].fillna(df[c].median())
            method = "median"
        elif pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].ffill()
            method = "forward fill"
        else:
            mode = df[c].mode(dropna=True)
            df[c] = df[c].fillna(mode.iloc[0] if len(mode) else "Unknown")
            method = "mode"
        log.append(f"Filled {m} missing values in {c} using {method}.")
    return df, log, original_shape


def iqr_outliers(df, c):
    if not pd.api.types.is_numeric_dtype(df[c]):
        return 0
    s = df[c].dropna()
    if s.empty:
        return 0
    q1, q3 = s.quantile([.25, .75])
    i = q3 - q1
    return int(((s < q1 - 1.5 * i) | (s > q3 + 1.5 * i)).sum())


def detect_kpis(df):
    nums = df.select_dtypes(include=np.number).columns.tolist()
    keys = ["sales", "revenue", "profit", "amount", "price", "cost", "quantity", "qty", "total", "score"]
    return sorted(nums, key=lambda c: (any(k in c.lower() for k in keys), df[c].nunique()), reverse=True)


def insights(df, metric, dims, dates):
    out = []
    if metric and metric in df:
        s = df[metric].dropna()
        out.append(f"**{metric}** total is **{s.sum():,.2f}**, with an average of **{s.mean():,.2f}**.")
        n = iqr_outliers(df, metric)
        if n:
            out.append(f"⚠️ **{n} potential outlier(s)** detected in {metric} using the IQR method.")
    if dims and metric:
        g = df.groupby(dims[0])[metric].sum().sort_values(ascending=False)
        if len(g):
            out.append(f"🏆 Highest {metric} contribution: **{g.index[0]}** ({g.iloc[0]:,.2f}).")
        if len(g) > 1:
            out.append(f"📉 Lowest {metric} contribution: **{g.index[-1]}** ({g.iloc[-1]:,.2f}).")
    if dates and metric:
        t = df[[dates[0], metric]].dropna().sort_values(dates[0])
        if len(t) > 1:
            n = max(1, len(t) // 5)
            a = t.iloc[:n][metric].mean()
            b = t.iloc[-n:][metric].mean()
            if a:
                out.append(f"📈 Recent-vs-start period change in {metric}: **{(b-a)/abs(a)*100:+.1f}%**.")
    return out


def excel_bytes(df):
    b = io.BytesIO()
    with pd.ExcelWriter(b, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name="Cleaned Data")
    return b.getvalue()


# -----------------------------
# Sidebar controls
# -----------------------------
with st.sidebar:
    st.markdown('<div class="side-brand">📊 InsightFlow</div>', unsafe_allow_html=True)
    st.markdown('<div class="side-caption">Interactive Business Intelligence Studio</div>', unsafe_allow_html=True)

    dashboard_name = st.text_input("Dashboard name", "InsightFlow — Intelligent Data Analytics")
    subtitle = st.text_input("Subtitle", "Interactive Business Intelligence Dashboard")
    st.divider()
    uploaded = st.file_uploader("📂 Upload CSV / Excel", type=["csv", "xlsx", "xls"])
    sample = st.checkbox("Use sample data", value=uploaded is None)
    st.divider()
    st.caption("💡 Global filters refresh every visual, KPI and insight.")

if uploaded and not sample:
    raw = load_data(uploaded)
    source = uploaded.name
elif sample:
    raw = pd.read_csv("sample_data.csv")
    source = "sample_data.csv"
else:
    st.stop()

df, log, orig = clean_data(raw)
nums = df.select_dtypes(include=np.number).columns.tolist()
dims = [c for c in df.columns if c not in nums and not pd.api.types.is_datetime64_any_dtype(df[c]) and 1 < df[c].nunique() <= 50]
dates = df.select_dtypes(include=["datetime64[ns]"]).columns.tolist()

# Global filters
with st.sidebar:
    st.subheader("🔍 Global Filters")
    filtered = df.copy()
    for c in dims[:5]:
        vals = st.multiselect(c, sorted(filtered[c].dropna().astype(str).unique()), key="f_" + c)
        if vals:
            filtered = filtered[filtered[c].astype(str).isin(vals)]
    if dates:
        dc = dates[0]
        if not filtered.empty:
            dmin, dmax = filtered[dc].min().date(), filtered[dc].max().date()
            dr = st.date_input("Date range", (dmin, dmax), min_value=dmin, max_value=dmax)
            if isinstance(dr, tuple) and len(dr) == 2:
                filtered = filtered[(filtered[dc].dt.date >= dr[0]) & (filtered[dc].dt.date <= dr[1])]

kpis = detect_kpis(filtered)
with st.sidebar:
    metric = st.selectbox("Primary KPI", kpis if kpis else nums) if (kpis or nums) else None
    group = st.selectbox("Default grouping", dims) if dims else None

# -----------------------------
# Header
# -----------------------------
st.markdown(
    f'''<div class="pbi-topbar">
        <div class="brand-wrap">
            <div class="brand-icon">📊</div>
            <div style="min-width:0">
                <div class="brand-title">{dashboard_name}</div>
                <div class="brand-sub">{subtitle} &nbsp;·&nbsp; Source: {source}</div>
            </div>
        </div>
        <div class="live-pill">● Live interactive view</div>
    </div>''',
    unsafe_allow_html=True,
)

st.markdown(
    f'<div class="filter-strip">Showing <b>{len(filtered):,}</b> of <b>{len(df):,}</b> rows after global filters &nbsp;·&nbsp; '
    f'<b>{len(df.columns)}</b> columns</div>',
    unsafe_allow_html=True,
)

# KPI row
if nums and not filtered.empty:
    preferred = [metric] + [c for c in nums if c != metric]
    cols = st.columns(min(6, len(preferred)))
    for i, c in enumerate(preferred[:6]):
        with cols[i]:
            st.metric(c, f"{filtered[c].sum():,.2f}", f"avg {filtered[c].mean():,.2f}")
elif nums:
    st.warning("No rows match the current filters.")
else:
    st.warning("No numeric columns available.")

# -----------------------------
# Dashboard navigation
# -----------------------------
tabs = st.tabs(["📊 Overview", "📈 Trends", "🔎 Explorer", "🧹 Data Quality", "🤖 Insights", "📋 Data"])

with tabs[0]:
    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="section-card"><div class="section-title">Sales / KPI Trend</div>', unsafe_allow_html=True)
        if dates and metric and not filtered.empty:
            t = filtered.groupby(dates[0], as_index=False)[metric].sum()
            st.plotly_chart(px.line(t, x=dates[0], y=metric, markers=True), use_container_width=True, config={"displaylogo": False})
        elif group and metric and not filtered.empty:
            g = filtered.groupby(group, as_index=False)[metric].sum().sort_values(metric, ascending=False)
            st.plotly_chart(px.bar(g, x=group, y=metric), use_container_width=True, config={"displaylogo": False})
        else:
            st.info("Select a date or category and a numeric KPI.")
        st.markdown('</div>', unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="section-card"><div class="section-title">Contribution / Distribution</div>', unsafe_allow_html=True)
        if group and metric and not filtered.empty:
            g = filtered.groupby(group, as_index=False)[metric].sum().sort_values(metric, ascending=False)
            st.plotly_chart(px.pie(g, names=group, values=metric, hole=.35), use_container_width=True, config={"displaylogo": False})
        elif metric and not filtered.empty:
            st.plotly_chart(px.histogram(filtered, x=metric, nbins=30), use_container_width=True, config={"displaylogo": False})
        else:
            st.info("Select a numeric KPI to visualize distribution.")
        st.markdown('</div>', unsafe_allow_html=True)

with tabs[1]:
    if dates and metric and not filtered.empty:
        freq = st.selectbox("Time aggregation", ["Daily", "Weekly", "Monthly"])
        d = filtered[[dates[0], metric]].dropna().set_index(dates[0])
        rule = {"Daily": "D", "Weekly": "W", "Monthly": "ME"}[freq]
        tr = d.resample(rule)[metric].sum().reset_index()
        st.plotly_chart(px.area(tr, x=dates[0], y=metric, markers=True, title=f"{freq} {metric}"), use_container_width=True, config={"displaylogo": False})
    else:
        st.info("A date and numeric KPI are required for trend analysis.")

with tabs[2]:
    st.subheader("🧩 Build Your Own Visual")
    a, b, c, d = st.columns(4)
    x = a.selectbox("X / Dimension", df.columns)
    y = b.selectbox("Y / Metric", nums if nums else df.columns)
    typ = c.selectbox("Chart", ["Bar", "Line", "Area", "Scatter", "Box", "Histogram", "Pie"])
    agg = d.selectbox("Aggregation", ["Sum", "Mean", "Count", "Median"])
    if not filtered.empty:
        if x != y and typ not in ["Scatter", "Box", "Histogram"]:
            g = filtered.groupby(x)[y].agg({"Sum": "sum", "Mean": "mean", "Count": "count", "Median": "median"}[agg]).reset_index()
        else:
            g = filtered
        if typ == "Bar": fig = px.bar(g, x=x, y=y)
        elif typ == "Line": fig = px.line(g, x=x, y=y, markers=True)
        elif typ == "Area": fig = px.area(g, x=x, y=y)
        elif typ == "Scatter": fig = px.scatter(filtered, x=x, y=y)
        elif typ == "Box": fig = px.box(filtered, x=x, y=y)
        elif typ == "Pie": fig = px.pie(g, names=x, values=y, hole=.35)
        else: fig = px.histogram(filtered, x=y, nbins=30)
        fig.update_layout(margin=dict(l=10, r=10, t=45, b=10))
        st.plotly_chart(fig, use_container_width=True, config={"displaylogo": False})
    else:
        st.warning("No data matches the current filters.")

with tabs[3]:
    st.subheader("🧹 Data Quality & Cleaning Audit")
    missing = int(raw.isna().sum().sum())
    duplicates = int(raw.duplicated().sum())
    out = sum(iqr_outliers(df, c) for c in nums)
    qcols = st.columns(4)
    qcols[0].metric("Rows", f"{len(df):,}")
    qcols[1].metric("Missing cells", f"{missing:,}")
    qcols[2].metric("Duplicates", f"{duplicates:,}")
    qcols[3].metric("Potential outliers", f"{out:,}")
    score = max(0, min(100, 100 - (missing / max(1, raw.size) * 100) - (duplicates / max(1, len(raw)) * 100) - min(20, out / max(1, len(df)) * 100)))
    st.progress(score / 100)
    st.write(f"**Data Quality Score: {score:.1f}/100**")
    st.write("**Cleaning log**")
    if log:
        for x in log:
            st.write("• " + x)
    else:
        st.success("No automatic cleaning changes were required.")
    st.dataframe(df.head(100), use_container_width=True)

with tabs[4]:
    st.subheader("🤖 Automated Business Insights")
    insight_list = insights(filtered, metric, dims, dates)
    if insight_list:
        for x in insight_list:
            st.markdown("• " + x)
    else:
        st.info("Select a numeric KPI to generate insights.")

with tabs[5]:
    st.subheader("📋 Filtered Data Explorer")
    st.dataframe(filtered, use_container_width=True, height=500)
    a, b = st.columns(2)
    a.download_button("⬇️ Download CSV", filtered.to_csv(index=False).encode(), "filtered_data.csv", "text/csv")
    b.download_button("⬇️ Download Excel", excel_bytes(filtered), "filtered_data.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
